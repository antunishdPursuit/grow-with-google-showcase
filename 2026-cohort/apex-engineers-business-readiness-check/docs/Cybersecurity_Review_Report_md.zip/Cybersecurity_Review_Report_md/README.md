# Cybersecurity Review Report — Small Business Tech-Stack Diagnostic Tool

This folder contains the markdown version of the Cybersecurity Review Report,
generated from the team-verified final `.docx`.

## Contents

- `Cybersecurity_Review_Report.md` — the full report
- `images/` — the 9 charts referenced in the report (`figure-01.png` through `figure-09.png`, in reading order)

## Source

Generated from `Cybersecurity_Review_Report_Final.docx`. All 13 sources in
the Sources section are verified, including source [10], and carry live
hyperlinks.

Push this folder as-is to a repository; image paths are relative, so
`Cybersecurity_Review_Report.md` renders correctly on GitHub with no
further changes.
